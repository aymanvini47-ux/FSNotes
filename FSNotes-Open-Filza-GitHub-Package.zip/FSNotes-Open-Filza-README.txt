FSNotes source modification: Open Filza button

This ZIP contains the supplied FSNotes source with an additional “Open Filza” row in the FSNotes section of Settings. The row calls the filza:// URL scheme and displays an alert if iOS reports that the URL could not be opened.

IMPORTANT LIMITATIONS
- This is SOURCE CODE ONLY, not an IPA.
- The supplied source project sets the iOS app target to iOS 18.0, so it is not compatible with the user's iOS 15.8.8 device as supplied.
- Lowering the deployment target alone does not guarantee compatibility or a successful build. A compatible older FSNotes source release and an iOS build environment (normally Xcode on a Mac) are still required.
- Some Filza TrollStore builds intentionally omit the filza:// URL scheme. In that case this button cannot launch Filza.
- Original project license and attribution files are retained.
