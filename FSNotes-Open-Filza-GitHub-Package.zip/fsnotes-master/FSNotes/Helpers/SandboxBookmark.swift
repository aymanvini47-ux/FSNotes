//
//  SandboxBookmark.swift
//  FSNotes
//
//  Created by Oleksandr Glushchenko on 8/6/17.
//  Copyright © 2017 Oleksandr Glushchenko. All rights reserved.
//

import Foundation

class SandboxBookmark {
    static var instance: SandboxBookmark? = nil
    var bookmarks = [URL: Data]()
    var successfullyRestored = [URL]()
    
    public static func sharedInstance() -> SandboxBookmark {
        guard let sandbox = self.instance else {
            self.instance = SandboxBookmark()
            return self.instance!
        }
        return sandbox
    }
    
    public func resetBookmarksDb() {
        if let url = bookmark() {
            try? FileManager.default.removeItem(at: url)
        }
    }
    
    func bookmark() -> URL? {
        if var url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first {
            url = url.appendingPathComponent("Bookmarks.dict")
            
            return url
        }
        
        return nil
    }
    
    func load() {
        guard let url = bookmark() else { return }

        if FileManager.default.fileExists(atPath: url.path),
            let data = try? Data(contentsOf: url) {
            do {
                if let bookmarks = try NSKeyedUnarchiver.unarchivedObject(ofClasses: [NSDictionary.self, NSURL.self, NSData.self], from: data) as? [URL: Data] {
                    self.bookmarks = bookmarks

                    for bookmark in bookmarks {
                        _ = restore(bookmark)
                    }
                }
            } catch {
                print("Failed to unarchive bookmarks: \(error.localizedDescription)")
            }
        }
    }
    
    func save() {
        guard let fileURL = bookmark() else { return }
        
        do {
            let data = try NSKeyedArchiver.archivedData(withRootObject: bookmarks, requiringSecureCoding: false)
            try data.write(to: fileURL)
        } catch {
            print("Failed to save bookmarks: \(error.localizedDescription)")
        }
    }
    
    func store(url: URL) {
        #if os(OSX)
        do {
            let data = try url.bookmarkData(options: NSURL.BookmarkCreationOptions.withSecurityScope, includingResourceValuesForKeys: nil, relativeTo: nil)
            bookmarks[url] = data
        } catch {
            Swift.print(error)
            Swift.print("Error storing bookmarks")
        }
        #endif
    }
    
    func restore(_ bookmark: (key: URL, value: Data)) -> Bool {
        #if os(OSX)
        let restoredUrl: URL?
        var isStale = false
        
        do {
            restoredUrl = try URL.init(resolvingBookmarkData: bookmark.value, options: NSURL.BookmarkResolutionOptions.withSecurityScope, relativeTo: nil, bookmarkDataIsStale: &isStale)
        } catch {
            Swift.print("Error restoring bookmarks: \(error)")
            restoredUrl = nil
            
            remove(url: bookmark.key)
            save()
        }

        guard let url = restoredUrl else { return false }

        if url.startAccessingSecurityScopedResource() {
            UserDefaultsManagement.updateCustomStoragePath(from: bookmark.key, to: url)

            if isStale {
                do {
                    let data = try url.bookmarkData(
                        options: .withSecurityScope,
                        includingResourceValuesForKeys: nil,
                        relativeTo: nil
                    )

                    bookmarks.removeValue(forKey: bookmark.key)
                    bookmarks[url] = data
                    save()
                } catch {
                    print("Couldn't refresh bookmark: \(error)")
                }
            }

            print("Bookmark restored: \(url.path)")
            successfullyRestored.append(url)
            return true
        }

        Swift.print("Couldn't access: \(url.path)")
        #endif

        return false
    }
    
    func remove(url: URL) {
        bookmarks.removeValue(forKey: url)
    }
    
    func removeBy(_ url: URL) {
        load()
        bookmarks.removeValue(forKey: url)
        save()
    }
    
    func rename(url: URL, new: URL) {
        let value = bookmarks[url]
        bookmarks[new] = value
        save()
    }
    
    public func save(url: URL) {
        guard let fileURL = bookmark() else { return }

        if self.bookmarks.isEmpty,
           FileManager.default.fileExists(atPath: fileURL.path),
            let data = try? Data(contentsOf: fileURL) {
            do {
                if let bookmarks = try NSKeyedUnarchiver.unarchivedObject(ofClasses: [NSDictionary.self, NSURL.self, NSData.self], from: data) as? [URL: Data] {
                    self.bookmarks = bookmarks
                }
            } catch {
                print("Failed to unarchive bookmarks: \(error.localizedDescription)")
            }
        }
        
        self.store(url: url)
        self.save()
    }
    
    public func getRestoredUrls() -> [URL] {
        if successfullyRestored.isEmpty {
            load()
        }
        
        return successfullyRestored
    }
}
